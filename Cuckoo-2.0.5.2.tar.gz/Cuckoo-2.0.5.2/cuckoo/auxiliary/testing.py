# Copyright (C) 2012-2013 Claudio Guarnieri.
# Copyright (C) 2014-2017 Cuckoo Foundation.
# This file is part of Cuckoo Sandbox - http://www.cuckoosandbox.org
# See the file 'docs/LICENSE' for copying permission.

import logging
import os
import subprocess

from cuckoo.common.abstracts import Auxiliary
from cuckoo.common.constants import CUCKOO_GUEST_PORT, faq
from cuckoo.common.exceptions import CuckooOperationalError
from cuckoo.misc import cwd, getuser, Popen

log = logging.getLogger(__name__)

class testing(Auxiliary):
    def __init__(self):
        Auxiliary.__init__(self)
        self.proc = None

    def start(self):
        """Starting of testing module
        it will print testing is going on"""
        log.info("Testing is going on")

    def stop(self):
        """Stop testing.
        @return: operation status.
        """
        log.info("testing stopped")
